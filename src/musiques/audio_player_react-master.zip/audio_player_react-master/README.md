# audio_player_react
a simple audio player with play, pause, skip, previous, and seek-bar, using react. No error checking or any valitiaon done.

Clone the repository and npm install in the same dir

