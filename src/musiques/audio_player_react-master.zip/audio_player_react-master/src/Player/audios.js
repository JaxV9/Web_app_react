exports.songsdata = [
    {
        "title": "Drake - Forever",
        "url": "https://beardbarnmusicbucket.s3.amazonaws.com/The+Wild+Horse"
    },
    {
        "title": "Linking Park - In the end",
        "url": "https://beardbarnmusicbucket.s3.amazonaws.com/The+Wild+Horse"
    },
    {
        "title": "Travis Scott - Stop trina be God",
        "url": "https://beardbarnmusicbucket.s3.amazonaws.com/The+Wild+Horse"
    }
]